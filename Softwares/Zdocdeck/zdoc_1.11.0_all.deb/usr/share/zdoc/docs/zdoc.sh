#!/bin/bash

set -e

if [ -e ~/.zdoc ]; then
    source ~/.zdoc
fi

STYLE_DIR=${STYLE_DIR:-/usr/share/zdoc}
MAKEFILE="$STYLE_DIR/docs/Makefile"

print_logo(){
printf "
   _____      __          
  /__  / ____/ /___  _____
    / / / __  / __ \/ ___/
   / /_/ /_/ / /_/ / /__  
  /____|__,_/\____/\___/  
\n"
}


print_usage(){
    printf "Usage: zdoc  --init (or) [-h | --help] [-s stylename] <Filename>\n
For More Details Use --help \n" >&2
}


print_help(){
    print_logo
    printf "Styled PDF Generation Tools using Asciidoc + Docbook + FOP\n
    options :
    -h --help   Print help.
    --init      Create Makefile for Project.
    -s --style  stylename (document, proposal, and handout) [default = document].

    Examples: 
	1. zdoc --init  
	2. zdoc -s document file.txt\n"
    exit 0
}

make_doc(){
    print_logo
    make -f "$MAKEFILE" STYLE_DIR="$STYLE_DIR" STYLE_CLASS="$1" "$2"
    exit 0
}

init_zdoc(){
    printf 'STYLE_DIR ?= %s\n' "$STYLE_DIR" > ./Makefile
    cat "$MAKEFILE" >>  ./Makefile
    exit 0
}


while getopts ':h:s:o:-:' OPTION; do
    case "$OPTION" in
	-)
	    case "${OPTARG}" in
               help)
                   print_help
                   ;;
	       style)
		   STYLE=${OPTARG}
                   ;;
	       init)
		   init_zdoc
                   ;;
	    esac;;
	s)
	    STYLE=${OPTARG}
	    ;;
	h)
	    print_usage && exit 0
	    ;;
	*)
	    print_usage && exit 1
	    ;;
    esac
done
shift $((OPTIND-1))



if [ "$1" != "" ];
then
    FILE="$1"
    PDF_FILE="${FILE%%.*}.pdf"

    test -f "$PDF_FILE" && printf "$PDF_FILE already Exist.\n" && exit 2

    ls "$1" >/dev/null || ( printf "ERR: File not Found $1\n" && exit 3 ) 

    if [ -z "$STYLE" ];
    then
	printf "Using Default style : document \n"
	STYLE="document"
    fi

    make_doc "$STYLE" "$PDF_FILE"
else
    print_usage
fi

exit 0
