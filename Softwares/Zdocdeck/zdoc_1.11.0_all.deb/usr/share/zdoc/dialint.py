#!/usr/bin/env python3

import sys
import gzip
import os.path

from xml.etree import ElementTree
from xml.parsers.expat import ExpatError

def usage(status):
    print("Usage: dialint <filename>")
    sys.exit(status)

def error(msg):
    sys.stderr.write("dialint: %s\n" % msg)
    sys.exit(1)

def warn(msg):
    sys.stderr.write("dialint: %s\n" % msg)

def dialint(filename):
    dia_fp = open(filename, "r", encoding="utf-8")
    try:
        dia_tree = ElementTree.parse(dia_fp)
    except ExpatError:
        error("gzipped dia file or malformed dia file")

    dia_root = dia_tree.getroot()

    warn_count = 0
    
    for element in dia_root.iter("{http://www.lysator.liu.se/~alla/dia/}attribute"):
        if element.get("name") == "file":
            string_tag = element.getchildren()[0]
            filename = string_tag.text.strip("#")
            if os.path.isabs(filename):
                warn("absolute path present '%s'" % filename)
                warn_count += 1

    if warn_count != 0:
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        usage(1)
        
    dialint(sys.argv[1])
